package com.capg.service;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Optional;

import javax.xml.bind.DatatypeConverter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.bean.Credential;
import com.capg.bean.Customer;
import com.capg.bean.Email;
import com.capg.bean.Merchant;

import com.capg.bean.Product;
import com.capg.bean.ThirdPartyMerchant;
import com.capg.bean.WishItem;
import com.capg.dao.CredentialsDao;
import com.capg.dao.CustomerDao;
import com.capg.dao.EmailDao;
import com.capg.dao.MerchantDao;
import com.capg.dao.OrderedItemDao;
import com.capg.dao.ProductDao;
import com.capg.dao.ThirdPartyDao;
import com.capg.dao.WishItemDao;

@Service
public class CapgService {

	@Autowired CustomerDao customerRepo;
	@Autowired WishItemDao customerWishRepo;
	@Autowired ProductDao productRepo;
	@Autowired MerchantDao merchantRepo;
	@Autowired EmailDao mailRepo;
	@Autowired OrderedItemDao orderedItemRepo;
	@Autowired CredentialsDao credentialRepo;
	@Autowired ThirdPartyDao thirdPartyRepo;
	public void registerCustomer(Customer customer) {
		customerRepo.save(customer);
	}
	
	public Customer findCustomerById(String custId) {  
		return customerRepo.findById(custId).get();
	}
	public void addCustomerWish(String custId,WishItem wish) {
		Customer customer = findCustomerById(custId);
		List<WishItem> wishList = customer.getWishItems();
		wishList.add(wish);
		customer.setWishItems(wishList);
		customerWishRepo.save(wish);
		customerRepo.save(customer);
	}
	
	public List<Customer> showCustomers() {
		return customerRepo.findAll();
	}
	
	public List<Product> showProducts(){
		return productRepo.findAll();
	}
	
	public List<Merchant> showMerchants(){
		return merchantRepo.findAll();
	}
	
	public List<Email> showEmails(){
		return mailRepo.findAll();
	}
	
	public List<Merchant> pendingMerchants(String isValid) {
	     if(isValid.equalsIgnoreCase("PENDING"))
        return  merchantRepo.pendingMerchants(isValid);
	     else 
	    	 return merchantRepo.findAll();
	}
	
	public List<Merchant> acceptMerchants(String MerId,String isValid) {
		Optional<Merchant> optional=merchantRepo.findById(MerId);
		if(isValid.equals("PENDING")){
			  Merchant merchant=optional.get();
			  merchant.setIsValid("ACCEPTED");
			  merchantRepo.save(merchant);
			  return merchantRepo.pendingMerchants(isValid);
		}
		else 
			return merchantRepo.findAll();
		
	}
	
	public List<Merchant> denyMerchants(String MerId,String isValid){
		Optional<Merchant> optional=merchantRepo.findById(MerId);
		if(isValid.equals("PENDING")){
			Merchant merchant=optional.get();
			merchant.setIsValid("REJECTED");
			merchantRepo.save(merchant);
			return merchantRepo.pendingMerchants(isValid);
		}
		else 
			return merchantRepo.findAll();
	}
	
	public double totalRevenue() {
		return orderedItemRepo.totalRevenue();
	}

	public void deleteMerchant(String merId) {
		merchantRepo.deleteById(merId);
		
	}

	public void inviteThirdParty(ThirdPartyMerchant inviteThirdParty) {
		thirdPartyRepo.save(inviteThirdParty);
			}

	public String encryptPassword(String password) throws NoSuchAlgorithmException {
		Credential cred = new Credential();
	       MessageDigest md = MessageDigest.getInstance("MD5");
	       md.update(password.getBytes());
	        byte[] digest = md.digest();
	        String myHash = DatatypeConverter.printHexBinary(digest).toUpperCase();
	     //   cred.setPassword(myHash);
	        return myHash;
	}

	public String registerMerchant(Merchant merchant, String password1) {
		try {
		if(merchant.getIsValid().equals("ACCEPTED")&&merchant.getMerType().equals("TP")) {
			ThirdPartyMerchant thirdPartyMerchant=thirdPartyRepo.getThirdPartyId(merchant.getEmailId());
			thirdPartyMerchant.setIsJoined("true");
			thirdPartyRepo.save(thirdPartyMerchant);
		}
		}
		catch(Exception exception) {
			return "Failed";
		}
		merchantRepo.save(merchant);
		Credential cred = new Credential();
		cred.setId(merchant.getMerId());
        cred.setPassword(password1);
        credentialRepo.save(cred);
		return merchant.getMerId();
	}


	public void sendMail(Email maildata) {
		
		mailRepo.save(maildata);
	}

	
	public List<Email> getMyMails() {
		// TODO Auto-generated method stub
		
		return mailRepo.getMailsBydata();
	}

	public List<Email> getInbox() {
		// TODO Auto-generated method stub
		
		return mailRepo.getInboxBydata();
	}
	}
