import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminServiceService } from '../admin-service.service';

@Component({
  selector: 'app-refund',
  templateUrl: './refund.component.html',
  styleUrls: ['./refund.component.css']
})
export class RefundComponent implements OnInit {

  constructor(private router: Router, private adminService:AdminServiceService) { }

  money:number;
  ngOnInit() {
  }
  refund(id)
  {
    this.adminService.refund(id).subscribe(
      data=>{
        if(data === 0){
          window.alert('Money will not be refunded')
        }
        else{
        this.money=data;
        }
      });
  }

}
