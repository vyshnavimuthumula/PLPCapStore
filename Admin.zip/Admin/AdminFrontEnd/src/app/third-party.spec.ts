import { ThirdParty } from './third-party';

describe('ThirdParty', () => {
  it('should create an instance', () => {
    expect(new ThirdParty()).toBeTruthy();
  });
});
