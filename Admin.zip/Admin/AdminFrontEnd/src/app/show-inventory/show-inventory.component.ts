import { Component, OnInit } from '@angular/core';
import { AdminServiceService } from '../admin-service.service';
import { Product } from '../Product';

@Component({
  selector: 'app-show-inventory',
  templateUrl: './show-inventory.component.html',
  styleUrls: ['./show-inventory.component.css']
})
export class ShowInventoryComponent implements OnInit {

  product:Product[];
  constructor(public productService:AdminServiceService) { }

  ngOnInit() {
  }


  showInventory(merchantId){
    this.productService.showInventory(merchantId).subscribe(response=>this.handleSuccessfulResponse(response));
  }

  handleSuccessfulResponse(response){
    this.product=response;
    console.log(this.productService);
  }
}
