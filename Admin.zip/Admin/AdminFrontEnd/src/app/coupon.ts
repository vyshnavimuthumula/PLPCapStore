import { OrderedItem } from './ordered-item';

export class Coupon {
 
    id: string;
    coupCode:string;
    discount:number;
}
