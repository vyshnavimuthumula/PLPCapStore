import { OrderedItem } from './ordered-item';

export class Transaction {
    transId:string;
    ordItem:OrderedItem;
    paymentMode:string;

}