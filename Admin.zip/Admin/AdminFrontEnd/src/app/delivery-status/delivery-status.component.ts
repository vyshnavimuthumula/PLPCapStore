import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-status',
  templateUrl: './delivery-status.component.html',
  styleUrls: ['./delivery-status.component.css']
})
export class DeliveryStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
