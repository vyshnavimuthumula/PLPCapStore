import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CouponGenerationComponent } from './coupon-generation.component';

describe('CouponGenerationComponent', () => {
  let component: CouponGenerationComponent;
  let fixture: ComponentFixture<CouponGenerationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CouponGenerationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CouponGenerationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
