package com.capg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.capg.bean.OrderedItem;
@Repository
public interface OrderedItemDao extends JpaRepository<OrderedItem,String>{
	
	@Query("select SUM(ordPrice) from OrderedItem")
	public double totalRevenue();
	
	@Query("select ordPrice from OrderedItem where ordId=:ordId")
	public double refundMoney(@Param("ordId") String ordId);
	
	@Query("from OrderedItem where ordStatus=:ordSt")
	List<OrderedItem> getAllProducts(@Param("ordSt") String ordStatus);
	

	@Query("from OrderedItem where ordStatus=:ordStatus OR ordStatus=:ordst")
	List<OrderedItem> getAllProductDetails(@Param("ordStatus") String ordStatus,@Param("ordst") String ordst);
	
	@Query("from OrderedItem where ordStatus='PLD'")
	List<OrderedItem> getPlacedProducts();
	
	@Query("from OrderedItem where ordStatus='DISP'")
	List<OrderedItem> getDispatchedProducts();
	
	@Query("from OrderedItem where ordId=:ordId and ordStatus=:ordStatus")
	List<OrderedItem> updatePlacedProducts(String ordId, String ordStatus);
	
	@Query("from OrderedItem where ordId=:ordId2 and ordStatus=:ordStatus2")
	List<OrderedItem> updateDispatchedProducts(@Param("ordId2") String ordId, @Param("ordStatus2") String ordStatus);
	
	@Query("from OrderedItem where ordId=:ordId3 and (ordStatus=:ordStatus3 OR ordStatus=:ordStatus4)")
	List<OrderedItem> updateProduct(@Param("ordId3") String ordId, @Param("ordStatus3") String ordStatus,@Param("ordStatus4") String ordStatus4);

}
