package com.capg.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capg.bean.Coupon;

public interface CouponDao extends JpaRepository<Coupon,String>{

}
