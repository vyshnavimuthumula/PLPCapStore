package com.capg.controller;

import java.security.NoSuchAlgorithmException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capg.bean.Coupon;
import com.capg.bean.Customer;
import com.capg.bean.Email;
import com.capg.bean.Merchant;
import com.capg.bean.OrderedItem;
import com.capg.bean.Product;
import com.capg.bean.ThirdPartyMerchant;
import com.capg.bean.WishItem;
import com.capg.exception.CapStoreException;
import com.capg.service.CapgService;

@CrossOrigin("http://localhost:4200")
@RestController
public class CapgController {

	@Autowired CapgService capgService;
	
	@RequestMapping(value = "/ecommerce/186125/getOrderedItems",method = RequestMethod.GET)
	public List<OrderedItem> getAllOrderedItems()
	{
		return capgService.getAllOrderedItems();
	}
	
	@PostMapping("/register")
	public void registerCustomer(@RequestBody Customer customer) {
		capgService.registerCustomer(customer);
	}
	@PostMapping("/addWish/{custId}")
	public void addCustomerWish(@PathVariable String custId,@RequestBody WishItem wish) {
		capgService.addCustomerWish(custId,wish);
	}
	
	@RequestMapping("/ecommerce/185755/showCust")
	public List<Customer> showCustomers(){
		return capgService.showCustomers();
	}
	
	@RequestMapping("/ecommerce/185755/showProd")
	public List<Product> showProducts(){
		return capgService.showProducts();
	}
	@RequestMapping("/ecommerce/185755/showMerch")
	public List<Merchant> showMerchants(){
		return capgService.showMerchants();
	}
	
	@RequestMapping("/ecommerce/185755/showEmail")
	public List<Email> showEmails(){
		return capgService.showEmails();
	}
	
	@RequestMapping("/ecommerce/185755/pendingMerchants/{isValid}")
	public List<Merchant> pendingMerchants(@PathVariable("isValid") String isValid){
		return capgService.pendingMerchants(isValid);
	}
	
	@PutMapping("/ecommerce/185755/acceptMerchants/{MerId}/{isValid}")
	public List<Merchant> acceptMerchants(@PathVariable("MerId")String MerId,@PathVariable("isValid")String isValid){
		 return capgService.acceptMerchants(MerId,isValid);
	}
	
	@PutMapping("/ecommerce/185755/denyMerchants/{MerId}/{isValid}")
	public List<Merchant> denyMerchants(@PathVariable("MerId")String MerId,@PathVariable("isValid")String isValid){
	return capgService.denyMerchants(MerId, isValid);
	}
	@RequestMapping(value="ecommerce/185697/registerMerchant/{password}",method=RequestMethod.POST) 
	  public Merchant registerMerchant(@RequestBody Merchant merchant,@PathVariable String password) throws NoSuchAlgorithmException {
		 String password1=capgService.encryptPassword(password);
		 return capgService.registerMerchant(merchant,password1);
	}
	@RequestMapping(value="ecommerce/185697/deletemerchant/{merId}",method=RequestMethod.DELETE) 
	  public void deleteMerchant(@PathVariable("merId") String merId) { 
		  capgService.deleteMerchant(merId); 
	}
	@RequestMapping(value="ecommerce/185697/invitemerchant",method=RequestMethod.POST) 
	  public void inviteMerchant(@RequestBody ThirdPartyMerchant inviteThirdParty) { 
		  capgService.inviteThirdParty(inviteThirdParty);
	}
	@PostMapping("ecommerce/185697/send")
	public void sendMail(@RequestBody Email maildata){
		capgService.sendMail(maildata);
	}
	
	@GetMapping("ecommerce/185697/getmymail")
	public List<Email> getMyMails() {
		return capgService.getMyMails();
	}
	@GetMapping("ecommerce/185697/getInbox")
	public List<Email> getInbox() {
		return capgService.getInbox();
	}
	@RequestMapping("/ecommerce/185738/totalRevenue")
	public double totalRevenue() {
		return capgService.totalRevenue();
	}
	@RequestMapping(value = "/ecommerce/185753/generateCoupon", method = RequestMethod.POST)
	public void generateCoupons(@RequestBody Coupon coupon) {
		capgService.generateCoupons(coupon);
	}
	@RequestMapping("/ecommerce/185753/getCoupon")
	public List<Coupon> getAllCoupons() {
		return capgService.getCoupons();

	}
	
	
	@RequestMapping("/ecommerce/185684/{ordStatus}/{ordst}")
	public List<OrderedItem> getAllProductDetails(@PathVariable String ordStatus,@PathVariable String ordst) throws CapStoreException{
		return capgService.getAllProductDetails(ordStatus,ordst);
	}	
	
	
	@RequestMapping(value="/ecommerce/185684/placedproducts")
	public List<OrderedItem> getProducts() throws CapStoreException{
			return capgService.getPlacedProducts();
		}
	
	@RequestMapping(value="/ecommerce/185684/dispatchedproducts")
	public List<OrderedItem> getDispatchedProducts() throws CapStoreException{
		return capgService.getDispatchedProducts();
	}
	
	@RequestMapping(value="/ecommerce/185684/updatePlacedProducts/{ordId}/{ordStatus}")
	public List<OrderedItem> updatePlacedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capgService.updatePlacedProducts(ordId,ordStatus);
	}
	
	@RequestMapping(value="/ecommerce/185684/updateDispatchedProducts/{ordId}/{ordStatus}")
	public List<OrderedItem> updateDispatchedProducts(@PathVariable String ordId,@PathVariable String ordStatus) throws CapStoreException{
		return capgService.updateDispatchedProducts(ordId,ordStatus);
	}
	
	@RequestMapping(value="/ecommerce/185684/updateProduct/{ordId}/{ordStatus}")
	public List<OrderedItem> updateProduct(@PathVariable String ordId,@PathVariable String ordStatus,String ordStatus4) throws CapStoreException{
		return capgService.updateProduct(ordId,ordStatus,ordStatus4);
	}
	
	@RequestMapping("/api/prodcuts/{merchantid}")
	public List<Product> getProducts(@PathVariable String merchantid){
		return capgService.getProductByMerchant(merchantid);
	}  
	
	@RequestMapping("/ecommerce/185756/refundMoney/{ordId}")
	public double refundMoney(@PathVariable("ordId") String ordId) {
		return capgService.refundMoney(ordId);
	}

}
